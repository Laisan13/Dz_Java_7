import java.time.DayOfWeek;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
        // Программа должна вывести все дни недели, кроме данного.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите имя текущего дня недели : ");
        String dayWeek = scr.nextLine();
        for ( java.time.DayOfWeek day: java.time.DayOfWeek.values()) {
            if (day.name().equalsIgnoreCase(dayWeek)) {
                continue;
            }
            System.out.println( day.name());
              {
            
        }
            
        }
    }
}