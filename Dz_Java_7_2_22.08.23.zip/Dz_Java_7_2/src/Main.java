import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Необходимо суммировать все нечётные целые числа в диапазоне,
        // введённом пользователем. Программу повторять,
        // пока пользователь не введёт «quit».
        Scanner scr = new Scanner(System.in);

        int sum = 0;
        do {
            System.out.println("Введите первое число или quit для выхода: ");
            String lineNumber1 = scr.nextLine();
            if (lineNumber1.equals("quit")) {
                break;
            }
            System.out.println("Введите второе число или quit для выхода: ");
            String lineNumber2 = scr.nextLine();

            if (lineNumber2.equals("quit")) {
                break;
            }
            boolean isNumber1 = true;
            for (int i = 0; i < lineNumber1.length(); i++) {
                char c = lineNumber1.charAt(i);
                isNumber1 = isNumber1 && Character.isDigit(c);
            }
            if (!isNumber1) {
                System.out.println("Введено не число");
                continue;
            }
            boolean isNumber2 = true;
            for (int i = 0; i < lineNumber2.length(); i++) {
                char c = lineNumber2.charAt(i);
                isNumber2 = isNumber2 && Character.isDigit(c);
            }
            if (!isNumber2) {
                System.out.println("Введено не число");
                continue;
            }
            int number1 = Integer.parseInt(lineNumber1);
            int number2 = Integer.parseInt(lineNumber2);
            for (int i = Math.min(number1, number2); i <= Math.max(number1, number2); i++) {
                if (i % 2 != 0) {
                    sum += i;
                }

            }

        } while (true);
        System.out.println("Сумма чисел " + sum);


    }
}